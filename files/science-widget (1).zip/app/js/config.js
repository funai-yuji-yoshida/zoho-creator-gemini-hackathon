/* config.js — Creator のフォーム／レポート名と項目名の対応表（変更はここだけ） */
var CFG = {
  STORAGE_PREFIX: 'sciplan_',
  FORMS:   { Classes: 'Sci_Class_Form', Exps: 'Sci_Experiment_Form', Plans: 'Sci_Plan_Form', Chems: 'Sci_Chemical_Form', ExpChems: 'Sci_ExpChem_Form' },
  REPORTS: { Classes: 'Sci_Class_Report', Exps: 'Sci_Experiment_Report', Plans: 'Sci_Plan_Report', Chems: 'Sci_Chemical_Report', ExpChems: 'Sci_ExpChem_Report' },
  FIELD_MAP: {
    Classes:  { School_Year: 'school_year', Grade: 'grade', Class_Count: 'class_count', Students_Per_Class: 'students_per_class', Groups_Per_Class: 'groups_per_class', Note: 'note', Is_Active: 'is_active' },
    Exps:     { Exp_Key: 'exp_key', Exp_Name: 'exp_name', Unit_Name: 'unit_name', Note: 'note', Is_Active: 'is_active' },
    Plans:    { Plan_Key: 'plan_key', School_Year: 'school_year', Grade: 'grade', Month: 'plan_month', Date: 'plan_date', Unit_Name: 'unit_name', Exp_Key: 'exp_key', Exp_Name: 'exp_name', Note: 'note', Is_Active: 'is_active' },
    Chems:    { Chem_Key: 'chem_key', Chem_Name: 'chem_name', Unit: 'unit', Stock_Qty: 'stock_qty', Ordered_Qty: 'ordered_qty', Arrival_Date: 'arrival_date', Lead_Days: 'lead_days', Supplier: 'supplier', Hazard: 'hazard', Order_By: 'order_by', Shortage_Qty: 'shortage_qty', Alert_Level: 'alert_level', Note: 'note', Is_Active: 'is_active' },
    ExpChems: { Exp_Key: 'exp_key', Exp_Name: 'exp_name', Chem_Key: 'chem_key', Chem_Name: 'chem_name', Basis: 'basis', Amount: 'amount', Unit: 'unit', Is_Active: 'is_active' }
  },
  BOOL_FIELDS: ['Is_Active'],
  MAX_RECORDS: 1000,
  CHECK_DAYS: 7,      /* 発注期限の何日前を「薬品確認の期限」とするか */
  WARN_DAYS: 14       /* 発注期限まで何日以内を「要発注」とするか */
};
