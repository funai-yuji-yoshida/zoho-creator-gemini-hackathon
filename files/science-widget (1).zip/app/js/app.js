/* =========================================================================
 * app.js — 理科 指導計画・薬品管理
 *   計算の流れ：指導計画（学年・月・実験）× 実験ごとの使用薬品 × クラス規模
 *               → 薬品ごとの使用日・必要量 → 在庫/発注済と突き合わせ → 不足日 − 納品日数 = 発注期限
 * ========================================================================= */
var App = (function () {
  var state = { classes: [], exps: [], plans: [], chems: [], ecs: [], year: 0, me: null };
  var ui = { tab: 'dash', planGrade: '', selExp: '', preview: null, busy: '' };
  var TABS = [['dash', 'ダッシュボード'], ['chemlist', '薬品一覧'], ['monthly', '月別使用量'], ['plan', '指導計画'],
              ['exps', '実験と使用薬品'], ['chems', '薬品マスタ'], ['classes', 'クラス・人数']];
  var BASIS = { per_group: '1班あたり', per_student: '1人あたり', per_class: '1クラスあたり' };
  var MONTHS = [4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2, 3];
  var RANK = { '期限超過': 0, '要発注': 1, '余裕あり': 2, '在庫OK': 3, '予定なし': 4 };
  var BADGE = { '期限超過': 'b-over', '要発注': 'b-warn', '余裕あり': 'b-info', '在庫OK': 'b-ok', '予定なし': 'b-none' };

  /* ---------- 共通 ---------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function pad(n) { return String(n).padStart(2, '0'); }
  function fmt(n) { return (Math.round(Num.num(n) * 100) / 100).toLocaleString('ja-JP'); }
  function todayStr() { var d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function addDays(s, n) { var p = s.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2] + n)).toISOString().slice(0, 10); }
  function diffDays(a, b) { var x = a.split('-'), y = b.split('-'); return Math.round((Date.UTC(+y[0], +y[1] - 1, +y[2]) - Date.UTC(+x[0], +x[1] - 1, +x[2])) / 864e5); }
  function schoolYearOf(dateStr) { var p = dateStr.split('-'); return +p[1] >= 4 ? +p[0] : +p[0] - 1; }
  function isDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')); }
  function sameYear(v) { return String(v) === String(state.year); }
  function active(list) { return list.filter(function (r) { return r.Is_Active !== false; }); }
  function byKey(list, f, k) { return list.filter(function (r) { return r[f] === k; })[0]; }

  /* ---------- 計算 ---------- */
  function planDate(p) {
    if (isDate(p.Date)) return p.Date;
    var m = Num.num(p.Month), y = Num.num(p.School_Year) || state.year;
    return (m >= 4 ? y : y + 1) + '-' + pad(m) + '-01';
  }
  function classOf(grade) {
    return active(state.classes).filter(function (c) { return sameYear(c.School_Year) && String(c.Grade) === String(grade); })[0];
  }
  function multiplier(basis, c) {
    if (!c) return 0;
    var n = Num.num(c.Class_Count);
    if (basis === 'per_student') return n * Num.num(c.Students_Per_Class);
    if (basis === 'per_class') return n;
    return n * Num.num(c.Groups_Per_Class);
  }
  function usages() {
    var out = [];
    active(state.plans).filter(function (p) { return sameYear(p.School_Year); }).forEach(function (p) {
      var c = classOf(p.Grade);
      active(state.ecs).filter(function (e) { return e.Exp_Key === p.Exp_Key; }).forEach(function (e) {
        out.push({ plan: p, chemKey: e.Chem_Key, date: planDate(p), qty: Num.num(e.Amount) * multiplier(e.Basis, c), noClass: !c });
      });
    });
    return out;
  }
  function analyze() {
    var today = todayStr(), cutoff = today.slice(0, 8) + '01', us = usages();
    return active(state.chems).map(function (ch) {
      var mine = us.filter(function (u) { return u.chemKey === ch.Chem_Key; });
      var r = { chem: ch, annual: 0, remaining: 0, firstUse: '', shortDate: '', shortage: 0, orderBy: '', checkBy: '', level: '予定なし', monthly: MONTHS.map(function () { return { q: 0, t: [] }; }) };
      var ev = [];
      mine.forEach(function (u) {
        r.annual += u.qty;
        var mi = (Num.num(u.plan.Month) + 8) % 12, cell = r.monthly[isDate(u.plan.Date) ? (+u.date.split('-')[1] + 8) % 12 : mi];
        cell.q += u.qty; cell.t.push(u.plan.Exp_Name + '（' + u.plan.Grade + '年）');
        if (u.date >= cutoff) { r.remaining += u.qty; ev.push({ d: u.date, v: -u.qty, o: 1 }); if (!r.firstUse || u.date < r.firstUse) r.firstUse = u.date; }
      });
      if (Num.num(ch.Ordered_Qty) > 0) ev.push({ d: isDate(ch.Arrival_Date) ? ch.Arrival_Date : today, v: Num.num(ch.Ordered_Qty), o: 0 });
      ev.sort(function (a, b) { return a.d < b.d ? -1 : a.d > b.d ? 1 : a.o - b.o; });
      var bal = Num.num(ch.Stock_Qty), minBal = bal;
      ev.forEach(function (e) { bal += e.v; if (bal < 0 && !r.shortDate && e.v < 0) r.shortDate = e.d; if (bal < minBal) minBal = bal; });
      r.shortage = minBal < 0 ? Math.round(-minBal * 100) / 100 : 0;
      if (r.annual === 0) r.level = '予定なし';
      else if (!r.shortDate) r.level = '在庫OK';
      else {
        var lead = (ch.Lead_Days === '' || ch.Lead_Days == null) ? 7 : Num.num(ch.Lead_Days);
        r.orderBy = addDays(r.shortDate, -lead); r.checkBy = addDays(r.orderBy, -CFG.CHECK_DAYS);
        var left = diffDays(today, r.orderBy);
        r.level = left < 0 ? '期限超過' : left <= CFG.WARN_DAYS ? '要発注' : '余裕あり';
      }
      return r;
    }).sort(function (a, b) { return RANK[a.level] - RANK[b.level] || (a.orderBy || '9') .localeCompare(b.orderBy || '9') || a.chem.Chem_Name.localeCompare(b.chem.Chem_Name, 'ja'); });
  }
  /* 計算結果を薬品レコードに書き戻す（Creator 側の自動通知がこの値を見る）。現在の年度のときだけ */
  function syncAlerts(rows) {
    if (state.year !== schoolYearOf(todayStr())) return Promise.resolve();
    var chain = Promise.resolve();
    rows.forEach(function (r) {
      var ch = r.chem, patch = { Order_By: r.orderBy, Shortage_Qty: r.shortage, Alert_Level: r.level };
      if (String(ch.Order_By || '') === patch.Order_By && Num.num(ch.Shortage_Qty) === patch.Shortage_Qty && ch.Alert_Level === patch.Alert_Level) return;
      chain = chain.then(function () { return DB.update('Chems', ch.ID, patch).then(function () { Object.keys(patch).forEach(function (k) { ch[k] = patch[k]; }); }); })
        .catch(function (e) { console.warn('通知用の値を保存できませんでした', e); });
    });
    return chain;
  }

  /* ---------- 読み込み ---------- */
  function loadAll() {
    return Promise.all(['Classes', 'Exps', 'Plans', 'Chems', 'ExpChems'].map(function (e) { return DB.list(e); })).then(function (a) {
      state.classes = a[0]; state.exps = a[1]; state.plans = a[2]; state.chems = a[3]; state.ecs = a[4];
    });
  }
  function after() { render(); syncAlerts(analyze()); }
  function fail(e) { alert('保存に失敗しました：' + DB.errText(e)); }

  /* ---------- デモ用データ ---------- */
  function seed() {
    var sy = schoolYearOf(todayStr()), n = 0;
    function id() { return 'd' + (++n); }
    var cls = [[1, 4, 32, 8], [2, 4, 34, 8], [3, 3, 33, 8]].map(function (a) { return { ID: id(), School_Year: String(sy), Grade: String(a[0]), Class_Count: a[1], Students_Per_Class: a[2], Groups_Per_Class: a[3], Note: '', Is_Active: true }; });
    var chems = [['hcl', '塩酸（1mol/L）', 'mL', 2000, 0, 14, '劇物'], ['naoh', '水酸化ナトリウム', 'g', 100, 0, 14, '劇物'], ['cuso4', '硫酸銅（Ⅱ）五水和物', 'g', 0, 0, 21, '劇物'],
      ['iodine', 'ヨウ素液', 'mL', 300, 0, 7, ''], ['btb', 'BTB溶液', 'mL', 50, 0, 7, ''], ['mg', 'マグネシウムリボン', 'cm', 500, 0, 10, '']]
      .map(function (a) { return { ID: id(), Chem_Key: a[0], Chem_Name: a[1], Unit: a[2], Stock_Qty: a[3], Ordered_Qty: a[4], Arrival_Date: '', Lead_Days: a[5], Supplier: '○○理科商会', Hazard: a[6], Order_By: '', Shortage_Qty: 0, Alert_Level: '', Note: '', Is_Active: true }; });
    var E = [['e1', '光合成とデンプン（ヨウ素液）', '植物のつくりとはたらき'], ['e2', '酸とアルカリの中和', '化学変化とイオン'], ['e3', '金属の燃焼', '化学変化と原子・分子'], ['e4', '水溶液の電気分解', '化学変化とイオン']];
    var exps = E.map(function (a) { return { ID: id(), Exp_Key: a[0], Exp_Name: a[1], Unit_Name: a[2], Note: '', Is_Active: true }; });
    var EC = [['e1', 'iodine', 'per_group', 3], ['e2', 'hcl', 'per_group', 20], ['e2', 'naoh', 'per_group', 2], ['e2', 'btb', 'per_group', 3], ['e3', 'mg', 'per_group', 5], ['e4', 'cuso4', 'per_group', 8]];
    var ecs = EC.map(function (a) { var c = byKey(chems, 'Chem_Key', a[1]); return { ID: id(), Exp_Key: a[0], Exp_Name: byKey(exps, 'Exp_Key', a[0]).Exp_Name, Chem_Key: a[1], Chem_Name: c.Chem_Name, Basis: a[2], Amount: a[3], Unit: c.Unit, Is_Active: true }; });
    var P = [[1, 6, 'e1'], [3, 10, 'e4'], [3, 11, 'e2'], [2, 12, 'e3'], [3, 12, 'e2'], [2, 2, 'e3']];
    var plans = P.map(function (a, i) { var e = byKey(exps, 'Exp_Key', a[2]); return { ID: id(), Plan_Key: 'p' + i, School_Year: String(sy), Grade: String(a[0]), Month: a[1], Date: '', Unit_Name: e.Unit_Name, Exp_Key: a[2], Exp_Name: e.Exp_Name, Note: '', Is_Active: true }; });
    return { Classes: cls, Exps: exps, Plans: plans, Chems: chems, ExpChems: ecs };
  }

  /* ---------- 起動 ---------- */
  function boot() {
    DB.init(seed).then(function (res) {
      document.getElementById('mode').textContent = res.connected ? 'Zoho Creator 接続済' : 'デモモード（未接続）';
      var p = DB.initParams() || {};
      state.me = { login: p.loginUser || '', name: p.loginUser || 'デモ利用者' };
      document.getElementById('who').textContent = state.me.name;
      state.year = schoolYearOf(todayStr());
      var sel = document.getElementById('year');
      sel.innerHTML = [state.year - 1, state.year, state.year + 1].map(function (y) { return '<option value="' + y + '"' + (y === state.year ? ' selected' : '') + '>' + y + '年度</option>'; }).join('');
      sel.addEventListener('change', function () { state.year = +sel.value; render(); });
      return loadAll();
    }).then(function () { bind(); after(); }).catch(function (e) {
      console.error(e);
      document.getElementById('mode').textContent = '未接続';
      document.getElementById('view').innerHTML = '<div class="card">起動に失敗しました：' + esc(DB.errText(e)) + (e && e.diag ? '<div class="diag">SDK の状態：' + esc(e.diag) + '</div>' : '') + '</div>';
    });
  }

  /* ---------- 描画 ---------- */
  function render() {
    document.getElementById('tabs').innerHTML = TABS.map(function (t) { return '<button class="tab' + (t[0] === ui.tab ? ' on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>'; }).join('');
    var fn = { dash: vDash, chemlist: vChemList, monthly: vMonthly, plan: vPlan, exps: vExps, chems: vChems, classes: vClasses }[ui.tab];
    document.getElementById('view').innerHTML = fn();
  }
  function badge(l) { return '<span class="badge ' + BADGE[l] + '">' + l + '</span>'; }
  function table(head, rows, empty) {
    if (!rows.length) return '<div class="muted">' + empty + '</div>';
    return '<div class="table-wrap"><table><thead><tr>' + head.map(function (h) { return '<th>' + h + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>';
  }
  function daysText(d) { var n = diffDays(todayStr(), d); return n < 0 ? Math.abs(n) + '日超過' : n === 0 ? '本日' : 'あと' + n + '日'; }

  function vDash() {
    var rows = analyze(), urgent = rows.filter(function (r) { return r.level === '期限超過' || r.level === '要発注'; });
    var yp = active(state.plans).filter(function (p) { return sameYear(p.School_Year); });
    var t = todayStr(), m0 = t.slice(0, 7), m1 = addDays(t.slice(0, 8) + '01', 32).slice(0, 7);
    var soon = yp.filter(function (p) { var m = planDate(p).slice(0, 7); return m === m0 || m === m1; }).sort(function (a, b) { return planDate(a) < planDate(b) ? -1 : 1; });
    var us = usages();
    var warns = [];
    var noClass = {}; yp.forEach(function (p) { if (!classOf(p.Grade)) noClass[p.Grade] = 1; });
    if (Object.keys(noClass).length) warns.push('クラス数・人数が未登録の学年：' + Object.keys(noClass).sort().join('・') + '年（「クラス・人数」タブ）。登録するまで必要量が0になります。');
    var noChem = {}; yp.forEach(function (p) { if (!active(state.ecs).some(function (e) { return e.Exp_Key === p.Exp_Key; })) noChem[p.Exp_Name] = 1; });
    if (Object.keys(noChem).length) warns.push('使用薬品が未入力の実験：' + Object.keys(noChem).join('、') + '（「実験と使用薬品」タブ）');
    var h = '<div class="card"><div class="grid">' +
      '<div><div class="muted">期限超過・要発注の薬品</div><strong style="font-size:22px">' + urgent.length + '</strong></div>' +
      '<div><div class="muted">登録している薬品</div><strong style="font-size:22px">' + rows.length + '</strong></div>' +
      '<div><div class="muted">' + state.year + '年度の実験回数</div><strong style="font-size:22px">' + yp.length + '</strong></div></div></div>';
    h += '<div class="card"><div class="h">発注・確認が必要な薬品</div>' + (urgent.length ? urgent.map(function (r) {
      return '<div class="alert' + (r.level === '要発注' ? ' warn' : '') + '">' + badge(r.level) + ' <strong>' + esc(r.chem.Chem_Name) + '</strong>　発注期限 ' + r.orderBy + '（' + daysText(r.orderBy) + '）／確認期限 ' + r.checkBy +
        '<div class="muted">不足 ' + fmt(r.shortage) + esc(r.chem.Unit) + '（' + r.shortDate + ' の実験から不足）・納品まで ' + fmt(r.chem.Lead_Days === '' ? 7 : r.chem.Lead_Days) + '日</div></div>';
    }).join('') : '<div class="muted">いま発注が必要な薬品はありません。</div>') + '</div>';
    if (warns.length) h += '<div class="card"><div class="h">入力が足りない項目</div>' + warns.map(function (w) { return '<div class="alert warn">' + esc(w) + '</div>'; }).join('') + '</div>';
    h += '<div class="card"><div class="h">今月・来月の実験と必要な薬品</div>' + table(['時期', '学年', '実験', '必要な薬品（全クラス分）'], soon.map(function (p) {
      var mine = us.filter(function (u) { return u.plan === p; });
      return '<tr><td>' + (isDate(p.Date) ? p.Date : p.Month + '月') + '</td><td>' + esc(p.Grade) + '年</td><td>' + esc(p.Exp_Name) + '</td><td>' +
        (mine.length ? mine.map(function (u) { var c = byKey(state.chems, 'Chem_Key', u.chemKey); return esc(c ? c.Chem_Name : u.chemKey) + ' ' + fmt(u.qty) + esc(c ? c.Unit : ''); }).join('<br>') : '<span class="muted">未入力</span>') + '</td></tr>';
    }), '今月・来月の実験はありません。') + '</div>';
    h += '<div class="muted">自動通知：このアプリは発注期限などを薬品レコードに保存します。メール等の自動通知は Creator のスケジュールで設定します（同梱の「導入手順.md」）。</div>';
    return h;
  }

  function vChemList() {
    var rows = analyze();
    return '<div class="card"><div class="h">' + state.year + '年度 薬品の必要量と発注期限</div><div class="muted" style="margin-bottom:8px">「今後の必要量」は今月以降の実験分。不足は 現在庫＋発注済み と使用予定を日付順に突き合わせて判定。発注期限＝不足になる日−納品日数、確認期限＝発注期限−' + CFG.CHECK_DAYS + '日。</div>' +
      table(['薬品', '年間必要量', '今後の必要量', '現在庫', '発注済', '不足', '初回使用', '確認期限', '発注期限', '状態'], rows.map(function (r) {
        var c = r.chem, u = esc(c.Unit);
        return '<tr><td><strong>' + esc(c.Chem_Name) + '</strong>' + (c.Hazard ? ' <span class="muted">' + esc(c.Hazard) + '</span>' : '') + '</td><td class="num">' + fmt(r.annual) + u + '</td><td class="num">' + fmt(r.remaining) + u + '</td><td class="num">' + fmt(c.Stock_Qty) + u + '</td><td class="num">' + fmt(c.Ordered_Qty) + u +
          '</td><td class="num">' + (r.shortage ? '<strong>' + fmt(r.shortage) + u + '</strong>' : '-') + '</td><td>' + (r.firstUse || '-') + '</td><td>' + (r.checkBy || '-') + '</td><td>' + (r.orderBy ? r.orderBy + '<div class="muted">' + daysText(r.orderBy) + '</div>' : '-') + '</td><td>' + badge(r.level) + '</td></tr>';
      }), '薬品が登録されていません。') + '</div>';
  }

  function vMonthly() {
    var rows = analyze().filter(function (r) { return r.annual > 0; });
    return '<div class="card"><div class="h">' + state.year + '年度 月別の薬品使用量</div><div class="muted" style="margin-bottom:8px">数値にカーソルを合わせる（スマホは長押し）と、その月に使う実験が表示されます。</div>' +
      table(['薬品'].concat(MONTHS.map(function (m) { return m + '月'; })).concat(['年間']), rows.map(function (r) {
        return '<tr><td><strong>' + esc(r.chem.Chem_Name) + '</strong> <span class="muted">' + esc(r.chem.Unit) + '</span></td>' + r.monthly.map(function (c) {
          return '<td class="num"' + (c.q ? ' title="' + esc(c.t.join('、')) + '"' : '') + '>' + (c.q ? fmt(c.q) : '') + '</td>';
        }).join('') + '<td class="num"><strong>' + fmt(r.annual) + '</strong></td></tr>';
      }), '使用予定の薬品がありません。指導計画と「実験と使用薬品」を入力してください。') + '</div>';
  }

  function vPlan() {
    var list = active(state.plans).filter(function (p) { return sameYear(p.School_Year) && (!ui.planGrade || String(p.Grade) === ui.planGrade); })
      .sort(function (a, b) { return String(a.Grade).localeCompare(String(b.Grade)) || planDate(a).localeCompare(planDate(b)); });
    var h = '<div class="card"><div class="h">Excel から年間指導計画を取り込む（' + state.year + '年度）</div>' +
      '<div class="muted" style="margin-bottom:8px">列：学年 ／ 月 ／ 実施予定日（任意）／ 単元 ／ 実験名 ／ 備考。1つのセルに複数の実験を「、」区切りで書いても分けて取り込みます。同梱の「年間指導計画_テンプレート.xlsx」を使えます。</div>' +
      '<input type="file" id="file" accept=".xlsx,.xls,.csv">' + pvHtml() + '</div>';
    h += '<div class="card"><div class="h">1件ずつ追加</div><div class="row tight">' +
      '<select id="pg" style="max-width:90px">' + [1, 2, 3, 4, 5, 6].map(function (g) { return '<option value="' + g + '">' + g + '年</option>'; }).join('') + '</select>' +
      '<select id="pm" style="max-width:90px">' + MONTHS.map(function (m) { return '<option value="' + m + '">' + m + '月</option>'; }).join('') + '</select>' +
      '<input id="pd" type="date" style="max-width:150px" title="実施予定日（任意）"><input id="pu" class="grow" placeholder="単元">' +
      '<input id="pe" class="grow" list="explist" placeholder="実験名"><datalist id="explist">' + active(state.exps).map(function (e) { return '<option value="' + esc(e.Exp_Name) + '">'; }).join('') + '</datalist>' +
      '<button class="btn btn-primary" data-act="addPlan">追加</button></div></div>';
    h += '<div class="card"><div class="row" style="margin-bottom:10px"><div class="h" style="margin:0">指導計画（' + list.length + '件）</div><select id="pgf" style="max-width:110px"><option value="">全学年</option>' +
      [1, 2, 3, 4, 5, 6].map(function (g) { return '<option value="' + g + '"' + (ui.planGrade === String(g) ? ' selected' : '') + '>' + g + '年</option>'; }).join('') + '</select></div>' +
      table(['学年', '時期', '単元', '実験', '薬品設定', ''], list.map(function (p) {
        var n = active(state.ecs).filter(function (e) { return e.Exp_Key === p.Exp_Key; }).length;
        return '<tr><td>' + esc(p.Grade) + '年</td><td>' + (isDate(p.Date) ? p.Date : p.Month + '月') + '</td><td>' + esc(p.Unit_Name) + '</td><td>' + esc(p.Exp_Name) + '</td><td>' + (n ? n + '種類' : '<span class="badge b-warn">未入力</span>') +
          '</td><td><button class="btn btn-sm btn-danger" data-act="delPlan" data-id="' + esc(p.ID) + '">削除</button></td></tr>';
      }), '指導計画がありません。Excel を取り込むか、上のフォームから追加してください。') + '</div>';
    return h;
  }

  function vExps() {
    var list = active(state.exps).sort(function (a, b) { return a.Exp_Name.localeCompare(b.Exp_Name, 'ja'); });
    var h = '<div class="card"><div class="row tight"><input id="ne" class="grow" placeholder="実験名（新規）"><input id="nu" class="grow" placeholder="単元（任意）"><button class="btn btn-primary" data-act="addExp">実験を追加</button></div></div>';
    h += '<div class="card"><div class="h">年間の実験一覧</div>' + table(['実験', '単元', '使用薬品', '計画での実施回数', ''], list.map(function (e) {
      var nc = active(state.ecs).filter(function (x) { return x.Exp_Key === e.Exp_Key; }).length, np = active(state.plans).filter(function (p) { return sameYear(p.School_Year) && p.Exp_Key === e.Exp_Key; }).length;
      return '<tr' + (e.Exp_Key === ui.selExp ? ' style="background:var(--bg)"' : '') + '><td>' + esc(e.Exp_Name) + '</td><td>' + esc(e.Unit_Name) + '</td><td>' + (nc ? nc + '種類' : '<span class="badge b-warn">未入力</span>') + '</td><td>' + np + '</td><td><button class="btn btn-sm" data-act="selExp" data-key="' + esc(e.Exp_Key) + '">薬品を入力</button></td></tr>';
    }), '実験がありません。指導計画を取り込むか、上から追加してください。') + '</div>';
    var ex = byKey(state.exps, 'Exp_Key', ui.selExp);
    if (ex) {
      var ecs = active(state.ecs).filter(function (e) { return e.Exp_Key === ex.Exp_Key; });
      h += '<div class="card"><div class="h">「' + esc(ex.Exp_Name) + '」で使う薬品（手入力）</div>' + table(['薬品', '基準', '使用量', ''], ecs.map(function (e) {
        return '<tr><td>' + esc(e.Chem_Name) + '</td><td><select data-edit data-ent="ExpChems" data-id="' + esc(e.ID) + '" data-f="Basis">' + Object.keys(BASIS).map(function (k) { return '<option value="' + k + '"' + (e.Basis === k ? ' selected' : '') + '>' + BASIS[k] + '</option>'; }).join('') +
          '</select></td><td><input data-edit data-t="n" data-ent="ExpChems" data-id="' + esc(e.ID) + '" data-f="Amount" value="' + esc(e.Amount) + '" style="width:90px"> ' + esc(e.Unit) + '</td><td><button class="btn btn-sm btn-danger" data-act="delEC" data-id="' + esc(e.ID) + '">削除</button></td></tr>';
      }), 'まだ薬品が入力されていません。') +
        '<div class="row tight" style="margin-top:12px"><input id="cn" class="grow" list="chemlist" placeholder="薬品名（未登録なら自動で追加）"><datalist id="chemlist">' + active(state.chems).map(function (c) { return '<option value="' + esc(c.Chem_Name) + '">'; }).join('') + '</datalist>' +
        '<select id="cb" style="max-width:130px">' + Object.keys(BASIS).map(function (k) { return '<option value="' + k + '">' + BASIS[k] + '</option>'; }).join('') + '</select>' +
        '<input id="ca" placeholder="使用量" style="max-width:90px"><input id="cu" placeholder="単位（新規のみ）" value="mL" style="max-width:110px"><button class="btn btn-primary" data-act="addEC">追加</button></div></div>';
    }
    return h;
  }

  function editCell(ent, id, f, v, t, extra) {
    return '<input data-edit' + (t ? ' data-t="' + t + '"' : '') + ' data-ent="' + ent + '" data-id="' + esc(id) + '" data-f="' + f + '" value="' + esc(v) + '"' + (extra || '') + '>';
  }
  function vChems() {
    var list = active(state.chems).sort(function (a, b) { return a.Chem_Name.localeCompare(b.Chem_Name, 'ja'); });
    return '<div class="card"><div class="h">薬品を追加</div><div class="row tight"><input id="mn" class="grow" placeholder="薬品名"><input id="mu" placeholder="単位" value="mL" style="max-width:80px"><input id="ms" placeholder="現在庫" style="max-width:90px"><input id="ml" placeholder="納品日数" value="7" style="max-width:90px"><button class="btn btn-primary" data-act="addChem">追加</button></div></div>' +
      '<div class="card"><div class="h">薬品マスタ（在庫・発注済み・納品日数を更新すると発注期限が再計算されます）</div>' + table(['薬品', '単位', '現在庫', '発注済み数量', '納品予定日', '納品までの日数', '発注先', '区分', ''], list.map(function (c) {
        return '<tr><td>' + editCell('Chems', c.ID, 'Chem_Name', c.Chem_Name, '', ' style="min-width:140px"') + '</td><td>' + editCell('Chems', c.ID, 'Unit', c.Unit, '', ' style="width:60px"') + '</td><td>' + editCell('Chems', c.ID, 'Stock_Qty', c.Stock_Qty, 'n', ' style="width:80px"') + '</td><td>' + editCell('Chems', c.ID, 'Ordered_Qty', c.Ordered_Qty, 'n', ' style="width:80px"') +
          '</td><td><input type="date" data-edit data-ent="Chems" data-id="' + esc(c.ID) + '" data-f="Arrival_Date" value="' + esc(c.Arrival_Date) + '"></td><td>' + editCell('Chems', c.ID, 'Lead_Days', c.Lead_Days, 'n', ' style="width:70px"') + '</td><td>' + editCell('Chems', c.ID, 'Supplier', c.Supplier) + '</td><td>' + editCell('Chems', c.ID, 'Hazard', c.Hazard, '', ' style="width:80px"') +
          '</td><td><button class="btn btn-sm btn-danger" data-act="delChem" data-id="' + esc(c.ID) + '">削除</button></td></tr>';
      }), '薬品が登録されていません。') + '</div>';
  }

  function vClasses() {
    var list = active(state.classes).filter(function (c) { return sameYear(c.School_Year); }).sort(function (a, b) { return String(a.Grade).localeCompare(String(b.Grade)); });
    return '<div class="card"><div class="h">' + state.year + '年度 クラス数・人数規模を追加</div><div class="row tight"><select id="kg" style="max-width:90px">' + [1, 2, 3, 4, 5, 6].map(function (g) { return '<option value="' + g + '">' + g + '年</option>'; }).join('') + '</select>' +
      '<input id="kc" placeholder="クラス数" style="max-width:100px"><input id="ks" placeholder="1クラスの人数" style="max-width:130px"><input id="kb" placeholder="1クラスの班数" style="max-width:130px"><button class="btn btn-primary" data-act="addClass">追加</button></div></div>' +
      '<div class="card"><div class="h">登録済み</div>' + table(['学年', 'クラス数', '1クラスの人数', '1クラスの班数', '全体の人数', '全体の班数', ''], list.map(function (c) {
        return '<tr><td>' + esc(c.Grade) + '年</td><td>' + editCell('Classes', c.ID, 'Class_Count', c.Class_Count, 'n', ' style="width:70px"') + '</td><td>' + editCell('Classes', c.ID, 'Students_Per_Class', c.Students_Per_Class, 'n', ' style="width:70px"') + '</td><td>' + editCell('Classes', c.ID, 'Groups_Per_Class', c.Groups_Per_Class, 'n', ' style="width:70px"') +
          '</td><td class="num">' + fmt(multiplier('per_student', c)) + '人</td><td class="num">' + fmt(multiplier('per_group', c)) + '班</td><td><button class="btn btn-sm btn-danger" data-act="delClass" data-id="' + esc(c.ID) + '">削除</button></td></tr>';
      }), 'まだ登録されていません。') + '</div>';
  }

  /* ---------- Excel 取り込み ---------- */
  function cellDate(v) {
    if (v === '' || v == null) return '';
    if (typeof v === 'number') return v > 20000 ? new Date(Math.round((v - 25569) * 864e5)).toISOString().slice(0, 10) : '';
    var s = String(v).replace(/[０-９]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0xFEE0); }).replace(/[\/.年月]/g, '-').replace(/日/g, '').trim();
    var m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m) return m[1] + '-' + pad(+m[2]) + '-' + pad(+m[3]);
    m = s.match(/^(\d{1,2})-(\d{1,2})$/);
    if (m) return (+m[1] >= 4 ? state.year : state.year + 1) + '-' + pad(+m[1]) + '-' + pad(+m[2]);
    return '';
  }
  function parseSheet(wb) {
    var name = wb.SheetNames.filter(function (n) { return /指導計画/.test(n); })[0] || wb.SheetNames[0];
    var aoa = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: '', raw: true });
    var hi = -1, col = {};
    for (var i = 0; i < Math.min(aoa.length, 15) && hi < 0; i++) {
      var cells = aoa[i].map(function (c) { return String(c).replace(/\s/g, ''); });
      var c = { grade: cells.findIndex(function (x) { return /学年/.test(x); }), month: cells.findIndex(function (x) { return /^(実施|予定)?月$/.test(x); }),
        date: cells.findIndex(function (x) { return /(予定日|実施日|日付)/.test(x); }), unit: cells.findIndex(function (x) { return /単元/.test(x); }),
        exp: cells.findIndex(function (x) { return /(実験|観察)/.test(x); }), note: cells.findIndex(function (x) { return /備考/.test(x); }) };
      if (c.grade >= 0 && c.exp >= 0 && (c.month >= 0 || c.date >= 0)) { hi = i; col = c; }
    }
    if (hi < 0) return { error: '見出し行が見つかりません。「学年」「月」「実験名」の列が必要です（テンプレートをご利用ください）。' };
    var rows = [], errors = [], skipped = 0, g = '', m = '', u = '';
    for (var r = hi + 1; r < aoa.length; r++) {
      var row = aoa[r], get = function (k) { return col[k] >= 0 ? row[col[k]] : ''; };
      if (row.every(function (x) { return String(x).trim() === ''; })) continue;
      var gv = String(get('grade')).trim(), mv = String(get('month')).trim(), uv = String(get('unit')).trim();
      if (gv) g = gv; if (mv) m = mv; if (uv) u = uv;           /* 結合セルは直前の値を引き継ぐ */
      var exps = String(get('exp')).split(/[、,，\n]/).map(function (s) { return s.trim(); }).filter(Boolean);
      if (!exps.length) { skipped++; continue; }
      var gn = String(g).replace(/[０-９]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 0xFEE0); }).match(/[1-6]/);
      var date = cellDate(get('date')), mn = Num.parse(String(m).replace(/月/, ''));
      if (isNaN(mn) && date) mn = +date.split('-')[1];
      if (!gn) { errors.push((r + 1) + '行目：学年が読めません（' + g + '）'); continue; }
      if (isNaN(mn) || mn < 1 || mn > 12) { errors.push((r + 1) + '行目：月が読めません（' + m + '）'); continue; }
      exps.forEach(function (x) { rows.push({ Grade: gn[0], Month: mn, Date: date, Unit_Name: u, Exp_Name: x, Note: String(get('note')).trim() }); });
    }
    return { rows: rows, errors: errors, skipped: skipped, sheet: name };
  }
  function pvHtml() {
    var pv = ui.preview;
    if (ui.busy) return '<div class="alert warn" style="margin-top:10px">' + esc(ui.busy) + '</div>';
    if (!pv) return '';
    if (pv.error) return '<div class="alert" style="margin-top:10px">' + esc(pv.error) + '</div>';
    var known = {}; active(state.exps).forEach(function (e) { known[e.Exp_Name] = 1; });
    var fresh = {}; pv.rows.forEach(function (r) { if (!known[r.Exp_Name]) fresh[r.Exp_Name] = 1; });
    return '<div style="margin-top:12px"><div><strong>' + pv.rows.length + '件</strong>を取り込めます（シート：' + esc(pv.sheet) + '／実験なしの行 ' + pv.skipped + '件は除外／新しい実験 ' + Object.keys(fresh).length + '件を実験一覧に追加）</div>' +
      (pv.errors.length ? '<div class="alert warn" style="margin-top:8px">読めなかった行（取り込まれません）：<br>' + pv.errors.slice(0, 10).map(esc).join('<br>') + (pv.errors.length > 10 ? '<br>ほか' + (pv.errors.length - 10) + '件' : '') + '</div>' : '') +
      table(['学年', '月', '日付', '単元', '実験'], pv.rows.slice(0, 8).map(function (r) { return '<tr><td>' + r.Grade + '年</td><td>' + r.Month + '月</td><td>' + esc(r.Date) + '</td><td>' + esc(r.Unit_Name) + '</td><td>' + esc(r.Exp_Name) + '</td></tr>'; }), '') +
      (pv.rows.length > 8 ? '<div class="muted">先頭8件のみ表示</div>' : '') +
      '<label style="display:block;margin:10px 0"><input type="checkbox" id="rep" checked style="width:auto;min-height:0"> ' + state.year + '年度の同じ学年の既存の計画を置き換える（古い行は無効化されます）</label>' +
      '<button class="btn btn-primary" data-act="doImport"' + (pv.rows.length ? '' : ' disabled') + '>取り込む</button></div>';
  }
  function runImport() {
    var pv = ui.preview, replace = document.getElementById('rep').checked, steps = [], year = state.year;
    var names = {}; active(state.exps).forEach(function (e) { names[e.Exp_Name] = e.Exp_Key; });
    if (replace) {
      var gs = {}; pv.rows.forEach(function (r) { gs[r.Grade] = 1; });
      active(state.plans).filter(function (p) { return sameYear(p.School_Year) && gs[String(p.Grade)]; }).forEach(function (p) {
        steps.push(function () { return DB.update('Plans', p.ID, { Is_Active: false }).then(function () { p.Is_Active = false; }); });
      });
    }
    pv.rows.forEach(function (r, i) {
      if (!names[r.Exp_Name]) {
        var k = DB.uid('exp'); names[r.Exp_Name] = k;
        steps.push(function () { return DB.add('Exps', { Exp_Key: k, Exp_Name: r.Exp_Name, Unit_Name: r.Unit_Name, Note: '', Is_Active: true }).then(function (o) { state.exps.push(o); }); });
      }
      steps.push(function () {
        return DB.add('Plans', { Plan_Key: DB.uid('plan'), School_Year: String(year), Grade: r.Grade, Month: r.Month, Date: r.Date, Unit_Name: r.Unit_Name, Exp_Key: names[r.Exp_Name], Exp_Name: r.Exp_Name, Note: r.Note, Is_Active: true }).then(function (o) { state.plans.push(o); });
      });
    });
    var done = 0, chain = Promise.resolve();
    steps.forEach(function (s) { chain = chain.then(s).then(function () { done++; ui.busy = '取り込み中… ' + done + ' / ' + steps.length; var el = document.querySelector('#view .alert.warn'); if (el) el.textContent = ui.busy; }); });
    ui.busy = '取り込み中… 0 / ' + steps.length; render();
    chain.then(function () { ui.busy = ''; ui.preview = null; after(); alert('取り込みました。「実験と使用薬品」で、各実験の薬品と使用量を入力してください。'); })
      .catch(function (e) { ui.busy = ''; render(); alert('途中で失敗しました（' + done + '/' + steps.length + '件まで保存済み）：' + DB.errText(e)); });
  }

  /* ---------- 操作 ---------- */
  function val(id) { var el = document.getElementById(id); return el ? el.value.trim() : ''; }
  function findOrAddExp(name, unit) {
    var e = active(state.exps).filter(function (x) { return x.Exp_Name === name; })[0];
    if (e) return Promise.resolve(e);
    return DB.add('Exps', { Exp_Key: DB.uid('exp'), Exp_Name: name, Unit_Name: unit || '', Note: '', Is_Active: true }).then(function (o) { state.exps.push(o); return o; });
  }
  function softDelete(ent, list, id, msg) {
    if (!confirm(msg)) return;
    var r = byKey(list, 'ID', id); if (!r) return;
    DB.update(ent, id, { Is_Active: false }).then(function () { r.Is_Active = false; after(); }).catch(fail);
  }
  var ACT = {
    addPlan: function () {
      var name = val('pe'); if (!name) { alert('実験名を入れてください'); return; }
      var date = val('pd'), month = +val('pm'); if (date) month = +date.split('-')[1];
      findOrAddExp(name, val('pu')).then(function (e) {
        return DB.add('Plans', { Plan_Key: DB.uid('plan'), School_Year: String(state.year), Grade: val('pg'), Month: month, Date: date, Unit_Name: val('pu'), Exp_Key: e.Exp_Key, Exp_Name: e.Exp_Name, Note: '', Is_Active: true });
      }).then(function (o) { state.plans.push(o); after(); }).catch(fail);
    },
    delPlan: function (d) { softDelete('Plans', state.plans, d.id, 'この計画を削除しますか？'); },
    addExp: function () {
      var n = val('ne'); if (!n) { alert('実験名を入れてください'); return; }
      findOrAddExp(n, val('nu')).then(function (e) { ui.selExp = e.Exp_Key; after(); }).catch(fail);
    },
    selExp: function (d) { ui.selExp = d.key; render(); },
    addEC: function () {
      var name = val('cn'), amt = Num.parse(val('ca'));
      if (!name) { alert('薬品名を入れてください'); return; }
      if (isNaN(amt)) { alert('使用量が数値で読めません（例：20 / 2.5）'); return; }
      var ch = active(state.chems).filter(function (c) { return c.Chem_Name === name; })[0];
      var p = ch ? Promise.resolve(ch) : DB.add('Chems', { Chem_Key: DB.uid('chem'), Chem_Name: name, Unit: val('cu') || 'mL', Stock_Qty: 0, Ordered_Qty: 0, Arrival_Date: '', Lead_Days: 7, Supplier: '', Hazard: '', Order_By: '', Shortage_Qty: 0, Alert_Level: '', Note: '', Is_Active: true }).then(function (o) { state.chems.push(o); return o; });
      var ex = byKey(state.exps, 'Exp_Key', ui.selExp);
      p.then(function (c) {
        return DB.add('ExpChems', { Exp_Key: ex.Exp_Key, Exp_Name: ex.Exp_Name, Chem_Key: c.Chem_Key, Chem_Name: c.Chem_Name, Basis: val('cb'), Amount: amt, Unit: c.Unit, Is_Active: true });
      }).then(function (o) { state.ecs.push(o); after(); }).catch(fail);
    },
    delEC: function (d) { softDelete('ExpChems', state.ecs, d.id, 'この薬品を実験から外しますか？'); },
    addChem: function () {
      var n = val('mn'); if (!n) { alert('薬品名を入れてください'); return; }
      var s = val('ms') === '' ? 0 : Num.parse(val('ms')), l = val('ml') === '' ? 7 : Num.parse(val('ml'));
      if (isNaN(s) || isNaN(l)) { alert('在庫・納品日数は数値で入れてください'); return; }
      DB.add('Chems', { Chem_Key: DB.uid('chem'), Chem_Name: n, Unit: val('mu') || 'mL', Stock_Qty: s, Ordered_Qty: 0, Arrival_Date: '', Lead_Days: l, Supplier: '', Hazard: '', Order_By: '', Shortage_Qty: 0, Alert_Level: '', Note: '', Is_Active: true })
        .then(function (o) { state.chems.push(o); after(); }).catch(fail);
    },
    delChem: function (d) { softDelete('Chems', state.chems, d.id, 'この薬品を削除しますか？（使用薬品の設定は残ります）'); },
    addClass: function () {
      var c = Num.parse(val('kc')), s = Num.parse(val('ks')), b = Num.parse(val('kb'));
      if (isNaN(c) || isNaN(s) || isNaN(b)) { alert('クラス数・人数・班数を数値で入れてください'); return; }
      if (classOf(val('kg'))) { alert(val('kg') + '年は登録済みです。表の数値を直接書き換えてください。'); return; }
      DB.add('Classes', { School_Year: String(state.year), Grade: val('kg'), Class_Count: c, Students_Per_Class: s, Groups_Per_Class: b, Note: '', Is_Active: true })
        .then(function (o) { state.classes.push(o); after(); }).catch(fail);
    },
    delClass: function (d) { softDelete('Classes', state.classes, d.id, 'この学年の登録を削除しますか？'); },
    doImport: runImport
  };
  var LIST = { Classes: 'classes', Exps: 'exps', Plans: 'plans', Chems: 'chems', ExpChems: 'ecs' };

  function bind() {
    var v = document.getElementById('view');
    document.getElementById('tabs').addEventListener('click', function (e) { var b = e.target.closest('[data-tab]'); if (b) { ui.tab = b.dataset.tab; render(); } });
    v.addEventListener('click', function (e) { var b = e.target.closest('[data-act]'); if (b && ACT[b.dataset.act]) ACT[b.dataset.act](b.dataset); });
    v.addEventListener('change', function (e) {
      var t = e.target;
      if (t.id === 'pgf') { ui.planGrade = t.value; render(); return; }
      if (t.id === 'file') {
        var f = t.files[0]; if (!f) return;
        var fr = new FileReader();
        fr.onload = function () {
          try { ui.preview = parseSheet(XLSX.read(new Uint8Array(fr.result), { type: 'array' })); } catch (x) { ui.preview = { error: 'ファイルを読めませんでした：' + x.message }; }
          render();
        };
        fr.readAsArrayBuffer(f); return;
      }
      if (!t.matches('[data-edit]')) return;
      var rec = byKey(state[LIST[t.dataset.ent]], 'ID', t.dataset.id), f = t.dataset.f, x = t.value.trim();
      if (!rec) return;
      if (t.dataset.t === 'n') { x = x === '' ? '' : Num.parse(x); if (x !== '' && isNaN(x)) { alert('数値で入れてください'); render(); return; } }
      var patch = {}; patch[f] = x;
      DB.update(t.dataset.ent, t.dataset.id, patch).then(function () {
        rec[f] = x;
        if (t.dataset.ent === 'Chems' && f === 'Chem_Name') { /* 名前だけ変える。キーで結びついているので使用薬品は壊れない */ }
        after();
      }).catch(function (er) { fail(er); render(); });
    });
  }

  return { boot: boot, state: state, ui: ui, render: render, seed: seed, analyze: analyze, usages: usages, parseSheet: parseSheet };
})();

document.addEventListener('DOMContentLoaded', App.boot);
