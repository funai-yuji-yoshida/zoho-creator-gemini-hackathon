Zoho Creator × Gemini AI ハッカソン
参加者配布パッケージ Ver.2

【最初に】
01_参加者手順書 の「参加者向け_Gemini_ZohoCreator_ハッカソン手順書_Ver4.docx」を開いてください。

【Gem①】
Gem①_Ver.2_完成版.md を使用してください。
知識には以下の3ファイルを登録します。
・T1_押印申請.ds
・T2_稟議申請.ds
・T3_フィールド型リファレンス.ds

【Gem②】
Gem②_Ver.2_完成版.md を使用してください。
知識には以下の2ファイルを登録します。
・T1_押印申請.ds
・T2_稟議申請.ds

【注意】
・Sales_Management.ds は今回の標準ナレッジには含めません。
・T3_フィールド型リファレンス.ds はGem②には登録しません。
・フォームやフィールドを変更したい場合はGem②ではなくGem①に戻ります。
・Gem②を使う前に、Zoho Creatorから最新のDSをExportしてください。

【全体の流れ】
業務アイデア
→ Gem①
→ アプリ仕様書
→ 人間が確認・修正
→ OK
→ DS生成
→ Zoho Creator
→ 動作確認
→ 最新DSをExport
→ Gem②
→ ワークフロー・レポート追加
→ Zoho Creator
→ 完成
